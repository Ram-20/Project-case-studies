package com.training.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.model.Employee;

public class EmployeeRepository {
	
	List<Employee> employeeList = new ArrayList<Employee>();
	Set<Employee>  employeeSet = new HashSet<Employee>();
	
public void addEmployee(Employee e){
	//System.out.println("inside EmployeeRpository addEmployee method");
	boolean b = employeeSet.add(e);
	if(b){
	employeeList.add(e);
	}	
	}
	
	public List getAllEmployees(){
		//System.out.println("inside EmployeeRepository getAllEmployees method");
		return employeeList;
	}
	
	public Employee getEmployeeDetails(int id){
		
		Employee e=null;
		
		Iterator<Employee> i = employeeList.iterator();
		
		while(i.hasNext()){
			
			e=i.next();
			if(id==e.getId()){
				
				return e;
			}
						
		}
			
		
		return e;
	}
	
	public void updateEmployeeDetails(Employee updatedEmployee){
		
			Employee e=null;
		
		Iterator<Employee> i = employeeList.iterator();
		
		while(i.hasNext()){
			
			e=i.next();
			if(updatedEmployee.getId()==e.getId()){
				e.setSalary(updatedEmployee.getSalary());
							
			}
						
		}
		
		
	}
	
	public void removeEmployeeDetails(int id){
		
		Employee e=null;
		
		Iterator<Employee> i = employeeList.iterator();
		
		while(i.hasNext()){
			
			Employee emp=i.next();
			if(id==emp.getId()){
				
				e=emp;
			}
						
		}
		
		if(e!=null){
			employeeList.remove(e);
			
		}
		
		
	}



}
