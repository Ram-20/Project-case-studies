package com.training.service;

import java.util.List;

import com.training.model.Employee;
import com.training.repository.EmployeeRepository;

public class EmployeeService {
	private EmployeeRepository empRepo = new EmployeeRepository();
	
	
public void addEmployee(Employee e){
	//System.out.println("inside EmployeeService addEmployee method");
	empRepo.addEmployee(e);
		
	}
	
	public List getAllEmployees(){
		//System.out.println("inside EmployeeService getAllEmployees method");
		return empRepo.getAllEmployees();
	}
	
	public Employee getEmployeeDetails(int id){
		
		return empRepo.getEmployeeDetails(id);
	}
	
	public void updateEmployeeDetails(Employee updatedEmployee){
		empRepo.updateEmployeeDetails(updatedEmployee);
	}
	
	public void removeEmployeeDetails(int id){
		empRepo.removeEmployeeDetails(id);
	}


}
