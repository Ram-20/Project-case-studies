package com.training.model;

public class ContractEmployee extends Employee{

	private int contractPeriod;
	private String feedback;
	
	public ContractEmployee(){}
	
	public ContractEmployee(int id, String name, int leaves, int salary,int contractPeriod) {
		super(id, name, leaves, salary);
		this.contractPeriod =contractPeriod;
	}



	public int getContractPeriod() {
		return contractPeriod;
	}

	public void setContractPeriod(int contractPeriod) {
		this.contractPeriod = contractPeriod;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	@Override
	public void calculateSalary() {
		// TODO Auto-generated method stub
		
	}

}
