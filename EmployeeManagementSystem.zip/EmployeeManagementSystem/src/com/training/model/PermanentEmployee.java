package com.training.model;

public class PermanentEmployee extends Employee{

	private String designation;
	private int rating;
	
	public PermanentEmployee(){}
	
	public PermanentEmployee(int id, String name, int leaves, int salary,String designation) {
		super(id, name, leaves, salary);
		
		this.designation=designation;
	}



	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	@Override
	public void calculateSalary() {
		// TODO Auto-generated method stub
		
	}

}
