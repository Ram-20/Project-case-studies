package com.training.controller;

import java.util.Iterator;
import java.util.List;

import com.training.model.Employee;
import com.training.model.PermanentEmployee;

public class Main {

	public static void main(String[] args) {
		
		EmployeeController ec = new EmployeeController();		
		
		ec.addEmployee(new PermanentEmployee(101, "Kumar", 20, 30000,"developer"));
		ec.addEmployee(new PermanentEmployee(101, "Kumar", 20, 30000,"developer"));
		ec.addEmployee(new PermanentEmployee(102, "Ram", 20, 30000,"developer"));	
		ec.addEmployee(new PermanentEmployee(103, "Ravi", 20, 70000,"developer"));
		ec.addEmployee(new PermanentEmployee(104, "Vimal", 20, 80000,"developer"));
		
		ec.updateEmployeeDetails(new PermanentEmployee(101, "Kumar", 20, 50000,"developer"));
		//before removing
		System.out.println("Before removing employee object");
		getAllEmployees(ec);
		ec.removeEmployeeDetails(101);
		System.out.println("------------------------------------------------");
		System.out.println("After removing employee object");
		getAllEmployees(ec);
		System.out.println("Displaying employee details of id 103");
		getEmployeeDetails(ec,103);
	}
	
	public static void getEmployeeDetails(EmployeeController ec, int id){
		
		Employee e = ec.getEmployeeDetails(id);
		
		System.out.println("Id:"+e.getId());
		System.out.println("Name:"+e.getName());
		System.out.println("Salary:"+e.getSalary());
		
	}
	
	
	public static void getAllEmployees(EmployeeController ec){
		
		List<Employee> employeeList = ec.getAllEmployees();
		
		Iterator<Employee> i = employeeList.iterator();
		
		
		while(i.hasNext()){
			Employee e = i.next();
			
			System.out.println("Id:"+e.getId());
			System.out.println("Name:"+e.getName());
			System.out.println("Salary:"+e.getSalary());
			
			
			
		}
		
		
		
	}

}
