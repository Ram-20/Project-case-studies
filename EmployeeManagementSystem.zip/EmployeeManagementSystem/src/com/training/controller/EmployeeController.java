package com.training.controller;

import java.util.List;

import com.training.model.Employee;
import com.training.service.EmployeeService;

public class EmployeeController {
	
	private EmployeeService empService = new EmployeeService();
	
	public void addEmployee(Employee e){
		//System.out.println("inside EmployeeController addEmployee method");
		empService.addEmployee(e);
		
	}
	
	public List getAllEmployees(){
		//System.out.println("inside EmployeeController getAllEmployees method");
		return empService.getAllEmployees();
	}
	
	public Employee getEmployeeDetails(int id){
		
		return empService.getEmployeeDetails(id);
	}
	
	public void updateEmployeeDetails(Employee updatedEmployee){
		empService.updateEmployeeDetails(updatedEmployee);
	}
	
	public void removeEmployeeDetails(int id){
		empService.removeEmployeeDetails(id);
	}

}
